package com.RealShopAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealShopApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
