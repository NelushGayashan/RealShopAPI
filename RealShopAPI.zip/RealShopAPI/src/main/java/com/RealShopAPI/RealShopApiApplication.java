package com.RealShopAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealShopApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealShopApiApplication.class, args);
	}

}
